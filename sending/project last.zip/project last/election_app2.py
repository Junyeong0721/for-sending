# -*- coding: utf-8 -*-
import os, tempfile, random, re, traceback
import numpy as np
import pandas as pd
import altair as alt
import os
import streamlit as st
from math import erf, sqrt

from main_pipeline2 import train_and_predict, predict_candidates_via_transfer
from election_utils2 import load_current_poll, prob_trend_last_30days, load_transfer_matrix

# ===================== 공통 유틸/상수 =====================
phi = lambda z: 0.5 * (1.0 + erf(z / sqrt(2.0)))
random.seed(42); np.random.seed(42)

st.set_page_config(layout="wide", page_title="대선 예측 대시보드")
TOP_SLOT = st.empty()
alt.renderers.set_embed_options(actions={"export": True, "source": False, "editor": False})

# --- Query Param 읽기(세팅 복원) ---
_qp = st.query_params
def _qp_float(key, default):
    try: return float(_qp.get(key, default))
    except: return default
def _qp_int(key, default):
    try: return int(_qp.get(key, default))
    except: return default

# ---- 스타일(다크) ----
st.markdown("""
<style>
:root{
  --bg:#111827; --bg2:#1a2234; --card:#0f172a; --line:#2a3654;
  --txt:#E8EDF5; --sub:#A6B0C2; --pri:#2E6BFF;
}
html, body, [data-testid="stAppViewContainer"]{ background:var(--bg); }
.block-container { padding-top:1.2rem; }
.k-card { border-radius:16px; padding:16px; background:var(--card); color:var(--txt); border:1px solid var(--line); }
.k-title { font-size:13px; color:var(--sub); margin-bottom:6px; }
.k-big { font-size:26px; font-weight:700; line-height:1.2; }
.k-sub { font-size:12px; color:var(--sub); }
.k-badge { display:inline-block; padding:3px 8px; border-radius:999px; background:var(--bg2); color:var(--txt); border:1px solid var(--line); font-size:12px; margin-right:6px;}
.k-section { margin:8px 0 12px 0; padding:10px 14px; border-left:3px solid var(--pri); background:var(--bg2); border-radius:8px; color:var(--txt);}
.vega-embed *, .vega-tooltip { color: var(--txt) !important; }
</style>
""", unsafe_allow_html=True)

# ---- 필터/라벨 ----
NONPARTY_PATTERN = r'지지후보\s*없음|지지정당\s*없음|무응답|모름|없음'
OTHERS_REGEX     = r"(기타|군소|무소속)"

PARTY_COLOR_MAP = {
    "더불어민주당": "#3B82F6",
    "국민의힘":     "#EF4444",
    "개혁신당":     "#06B6D4",
    "정의당":       "#F59E0B",
    "진보당":       "#10B981",
    "조국혁신당":   "#22C55E",
    "기타정당":     "#8B94A7",
}
BALLOT_ORDER = ["더불어민주당","국민의힘","개혁신당","조국혁신당","정의당","진보당","기타정당"]
CANDIDATE_PRESET = {
    "더불어민주당":"이재명","국민의힘":"김문수","개혁신당":"이준석",
    "정의당":"권영국","조국혁신당":"조국","진보당":"김재연","기타정당":"기타정당 후보",
}

SORT_LABELS = {
    "mc_win_prob":       "승률(모의실험)",
    "mc_p50":            "예상 득표율(중앙값)",
    "nowcast_pp":        "나우캐스트 득표율",
    "predicted_vote_ml": "ML 예측 득표율",
    "predicted_vote_gpt":"AI 예측 득표율",
}
COLUMN_LABELS = {
    "순위":"순위","정당":"정당","mc_win_prob":"승률(모의실험)",
    "mc_p50":"예상 득표율(중앙값)","mc_p50_lo":"p50 하한","mc_p50_hi":"p50 상한",
    "mc_p80_lo":"p80 하한","mc_p80_hi":"p80 상한","nowcast_pp":"나우캐스트 득표율",
    "predicted_vote_ml":"ML 예측 득표율","predicted_vote_gpt":"AI 예측 득표율",
}
CAND_COLUMN_LABELS = {
    "후보":"후보","cand_win_prob":"승률(모의실험)","cand_p50":"예상 득표율(중앙값)",
    "cand_p50_lo":"p50 하한","cand_p50_hi":"p50 상한","cand_p80_lo":"p80 하한","cand_p80_hi":"p80 상한",
}

# ---------- 유틸 ----------
def apply_global_filters(preds: pd.DataFrame) -> pd.DataFrame:
    if preds is None or preds.empty: return preds
    df = preds.copy()
    df = df[~df['정당'].astype(str).str.contains(NONPARTY_PATTERN, case=False, na=False)]
    support_cols = [c for c in ['nowcast_pp','mc_p50','predicted_vote_ml','predicted_vote_gpt'] if c in df.columns]
    if support_cols:
        df = df[df[support_cols[0]].astype(float).fillna(0.0) >= 1.0]
    return df.reset_index(drop=True)

def donut_chart_df(df, label_col, prob_col, title="", topn=6, others_label="기타",
                   hide_numbers=False, min_label=4.0, color_map=None):
    if df is None or df.empty or label_col not in df.columns or prob_col not in df.columns:
        return None
    d = df[[label_col, prob_col]].dropna().copy().sort_values(prob_col, ascending=False)
    if topn and len(d) > topn:
        top = d.head(topn).copy()
        rest = pd.to_numeric(d[prob_col].iloc[topn:], errors="coerce").fillna(0.0).sum()
        if rest > 1e-6:
            top = pd.concat([top, pd.DataFrame({label_col:[others_label], prob_col:[rest]})], ignore_index=True)
        d = top
    d[prob_col] = pd.to_numeric(d[prob_col], errors="coerce").fillna(0.0).astype(float)
    d = d[d[prob_col] > 0]
    if d.empty: return None

    d["pct"] = d[prob_col] * 100.0
    name = d[label_col].astype(str)
    d["label_disp"] = name if hide_numbers else name + " " + d["pct"].map(lambda v: f"{v:.1f}%")

    win_lab = str(d.iloc[0][label_col]); win_pct = float(d.iloc[0]["pct"])
    title = (title + f" · 1위 {win_lab} {win_pct:.1f}%").strip(" ·")

    scale = None
    if color_map:
        labs = d[label_col].astype(str).tolist()
        scale = alt.Scale(domain=labs, range=[color_map.get(l, "#8B94A7") for l in labs])

    base = alt.Chart(d)
    donut = base.mark_arc(innerRadius=70, outerRadius=120, stroke='#0f172a', strokeWidth=1).encode(
        theta=alt.Theta("pct:Q", stack=True),
        color=alt.Color(f"{label_col}:N", legend=alt.Legend(title=None), scale=scale),
        tooltip=[alt.Tooltip(f"{label_col}:N"), alt.Tooltip("pct:Q", title="승률(%)", format=".1f")]
    )
    labels = base.transform_filter(f"datum.pct >= {float(min_label)}").mark_text(
        radius=145, size=13, color="#E8EDF5"
    ).encode(theta=alt.Theta("pct:Q", stack=True), text="label_disp:N")
    center_name = alt.Chart(pd.DataFrame({"txt":[win_lab]})).mark_text(
        align="center", baseline="middle", color="#E8EDF5", fontSize=18, dy=-6).encode(text="txt:N")
    center_pct  = alt.Chart(pd.DataFrame({"txt":[f"{win_pct:.1f}%"]})).mark_text(
        align="center", baseline="middle", color="#E8EDF5", fontSize=24, dy=16).encode(text="txt:N")

    chart = (donut + labels + center_name + center_pct).properties(width=420, height=360, title=title)
    chart = chart.configure_view(stroke=None, fill='#111827')\
                 .configure_legend(labelColor='#E8EDF5', titleColor='#E8EDF5')\
                 .configure_axis(gridColor='#2a3654', labelColor='#E8EDF5', titleColor='#E8EDF5')
    return chart

def apply_scenario(nowcast_series: pd.Series, deltas: dict, keep_total=True) -> pd.Series:
    if nowcast_series is None or nowcast_series.empty: return nowcast_series
    s0 = nowcast_series.astype(float).copy()
    s = s0.copy()
    for p, d in deltas.items():
        if p in s.index:
            s.loc[p] = max(0.0, s.loc[p] + float(d))
    if keep_total:
        t0, t1 = float(s0.sum()), float(s.sum())
        if t1 > 0 and t0 > 0: s *= (t0 / t1)
    return s

def pairwise_matrix(s: pd.Series, sigma_pp: float) -> pd.DataFrame:
    parties = s.index.tolist()
    mat = pd.DataFrame(index=parties, columns=parties, dtype=float)
    for a in parties:
        for b in parties:
            if a == b:
                mat.loc[a, b] = np.nan
            else:
                z = (float(s[a]) - float(s[b])) / max(1e-6, float(sigma_pp))
                mat.loc[a, b] = phi(z)
    return mat

# ===================== 사이드바(업로드/세팅) =====================
with st.sidebar:
    st.header("📂 데이터 & 설정")
    uploaded = st.file_uploader("최신 여론조사(.csv/.xlsx)", type=["csv","xlsx"])

# 업로드 전: 메인 화면에 이미지 크게 표시
if uploaded is None:
    HERO_IMG = r"C:\Users\user\OneDrive\바탕 화면\project last\intro.jpg"  # ← 경로 수정

    with TOP_SLOT.container():
        st.markdown("""
        <style>
          .block-container { padding-top: 0 !important; }   /* 위 여백 제거 */
          :root { --st-header-h: 3.2rem; }                  /* 필요시 3.0~3.6rem로 미세조정 */
          /* 이 페이지의 첫 번째 이미지(지금 우리가 그리는 것)만 풀-블리드/풀-높이 */
          div[data-testid="stImage"] img{
            width:100vw !important;
            height:calc(100vh - var(--st-header-h)) !important;
            object-fit:cover !important;
            border-radius:0 !important;
            display:block;
            margin-left:calc(50% - 50vw) !important;
            margin-right:calc(50% - 50vw) !important;
          }
        </style>
        """, unsafe_allow_html=True)
        st.image(HERO_IMG, use_container_width=True)

    st.stop()
# 업로드된 경우: 임시파일 생성
suffix = os.path.splitext(uploaded.name)[1]
with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
    tmp.write(uploaded.getbuffer())
    poll_path = tmp.name

    _ed = _qp.get("eday", "")
    try:
        _eday_default = pd.to_datetime(_ed).date() if _ed else (pd.Timestamp.today() + pd.Timedelta(days=30)).date()
    except Exception:
        _eday_default = (pd.Timestamp.today() + pd.Timedelta(days=30)).date()
    election_date = st.date_input("선거일", _eday_default)

    _sigma_d = _qp_float("sigma", 2.5)
    _hl_d    = _qp_int("hl", 7)
    _win_d   = _qp_int("win", 7)
    _hide_d  = (_qp.get("hide", "0") == "1")

    sigma      = st.slider("여론조사 오차 σ (스프레드·pp)", 0.5, 8.0, float(_sigma_d), 0.1, help="헤드투헤드/매트릭스 확률 계산에 사용")
    half_life  = st.slider("Nowcast 반감기(일)", 3, 21, int(_hl_d), 1)
    window     = st.slider("추세 롤링(일)", 1, 14, int(_win_d), 1)
    hide_numbers = st.toggle("🔒 수치 비공개(순위/게이지만)", value=_hide_d)

    st.divider()
    fast_mode_global = st.toggle("⚡ 고속 모드(전체)", value=True, help="발표/개발 중 빠르게 보려면 켜세요")

# ===================== 데이터 로드 =====================
try:
    polls_long = load_current_poll(poll_path)  # ['기관','날짜','정당','지지율']
    need = {'기관','날짜','정당','지지율'}
    miss = [c for c in need if c not in polls_long.columns]
    if miss:
        raise ValueError(f"업로드 데이터에 필수 컬럼 누락: {miss}")
    polls_long = polls_long[~polls_long['정당'].astype(str).str.contains(NONPARTY_PATTERN, case=False, na=False)]
    if polls_long.empty:
        st.error("업로드된 파일에서 유효한 '정당' 데이터가 없습니다.")
        st.stop()
    party_list = sorted([p for p in polls_long['정당'].dropna().unique().tolist() if str(p).strip()])
    if len(party_list) < 2:
        st.error("정당(또는 후보) 라벨이 2개 이상 필요합니다.")
        st.stop()
except Exception:
    st.error("파일을 읽는 중 오류가 발생했습니다.")
    with st.expander("자세한 오류 보기"):
        st.code("".join(traceback.format_exc()))
        st.markdown("- CSV/XLSX 첫 행은 헤더여야 합니다.\n- 필수 컬럼: `기관, 날짜, 정당, 지지율`")
    try: os.unlink(poll_path)
    except: pass
    st.stop()

# ---- 헤드투헤드 대상 복원 ----
_qp_pa = _qp.get("pa", party_list[0])
_qp_pb = _qp.get("pb", party_list[1] if len(party_list)>1 else party_list[0])

cA, cB = st.columns([1,1])
with cA:
    party_a = st.selectbox("A(헤드투헤드)", party_list, index=party_list.index(_qp_pa) if _qp_pa in party_list else 0)
with cB:
    party_b = st.selectbox("B(헤드투헤드)", party_list, index=party_list.index(_qp_pb) if _qp_pb in party_list else (1 if len(party_list)>1 else 0))
    if party_b == party_a and len(party_list) > 1:
        alt_list = [p for p in party_list if p != party_a]
        party_b = alt_list[0]

# ===================== 예측 계산 =====================
preds = pd.DataFrame()
try:
    preds = train_and_predict(
        poll_hist_path="과거 여론조사 결과.xlsx",
        res_hist_path="과거 대선 결과.xlsx",
        latest_poll_path=poll_path,
        sigma_pp=float(sigma),
        half_life_days=int(half_life),
    )
except Exception:
    st.error("예측 계산 중 오류가 발생했습니다.")
    with st.expander("자세한 오류 보기"):
        st.code("".join(traceback.format_exc()))
else:
    if preds is None or preds.empty:
        st.warning("예측 결과가 비어 있습니다.")

preds = apply_global_filters(preds)

def sort_and_rank(df):
    if df is None or df.empty: return df
    sort_candidates = [c for c in ['mc_win_prob','mc_p50','nowcast_pp','predicted_vote_ml','predicted_vote_gpt'] if c in df.columns]
    metric = sort_candidates[0] if sort_candidates else None
    if metric:
        secondary = []
        if metric == 'mc_win_prob':
            for cand in ['mc_p50','nowcast_pp','predicted_vote_ml','predicted_vote_gpt']:
                if cand in df.columns: secondary.append(cand)
        by_cols = [metric] + secondary
        df = df.sort_values(by=by_cols, ascending=[False]*len(by_cols), na_position='last')
    df = df.reset_index(drop=True)
    df.insert(0, '순위', range(1, len(df)+1))
    return df

preds_sorted = sort_and_rank(preds.copy()) if not preds.empty else preds

# =============== 시나리오 ===============
with st.expander("🎛️ 시나리오(지지율 ±%p)", expanded=False):
    sc_on = st.checkbox("시나리오 적용", value=(_qp.get("sc","0")=="1"))
    deltas = {}
    cols = st.columns(min(4, max(1, len(party_list))))
    for i, p in enumerate(party_list):
        with cols[i % len(cols)]:
            key = f"sc_{p}"
            default_delta = _qp_float(key, 0.0)
            deltas[p] = st.slider(p, -5.0, 5.0, float(default_delta), 0.1)

baseline_nowcast = (preds.set_index('정당')['nowcast_pp'].astype(float)
                    if ('정당' in preds and 'nowcast_pp' in preds)
                    else pd.Series(dtype=float))
scenario_nowcast = apply_scenario(baseline_nowcast, deltas, keep_total=True) if (baseline_nowcast is not None and not baseline_nowcast.empty and sc_on) else baseline_nowcast

# ===================== 헤더 =====================
st.title("📊 대선 예측 대시보드")
dmin, dmax = polls_long['날짜'].min(), polls_long['날짜'].max()
n_orgs = polls_long['기관'].nunique()
extra_badge = '<span class="k-badge">시나리오 ON</span>' if 'sc_on' in locals() and sc_on else ''
st.markdown(
    f'<div class="k-section">'
    f'<span class="k-badge">파일: {uploaded.name}</span>'
    f'<span class="k-badge">조사기관 {n_orgs:,}곳</span>'
    f'<span class="k-badge">{dmin:%Y-%m-%d} ~ {dmax:%Y-%m-%d}</span>'
    f'<span class="k-badge">선거일 {pd.to_datetime(election_date):%Y-%m-%d}</span>'
    f'<span class="k-badge">σ={sigma:.1f}pp · HL={int(_qp_int("hl",7))}일</span>'
    f'{extra_badge}'
    f'</div>', unsafe_allow_html=True
)

save_qp = {"pa": party_a, "pb": party_b, "sigma": f"{sigma:.2f}", "hl": _qp.get("hl","7"),
           "win": _qp.get("win","7"), "hide": "1" if hide_numbers else "0",
           "sc": "1" if ('sc_on' in locals() and sc_on) else "0", "eday": str(election_date)}
if 'deltas' in locals():
    for p, d in deltas.items(): save_qp[f"sc_{p}"] = f"{d:.1f}"
st.query_params.update(save_qp)

# ===================== 탭 =====================
tab_overview, tab_table, tab_trend, tab_matrix, tab_cand = st.tabs(["🏠 개요", "📋 예측표", "📈 추세", "🥊 매트릭스", "🧮 후보"])

# ------------------ 개요 ------------------
with tab_overview:
    st.subheader("한눈에 보기")
    colL, colC, colR = st.columns([1,1,1])

    with colL:
        n_labels = polls_long['정당'].nunique()
        st.markdown(
            f"""
            <div class="k-card">
              <div class="k-title">데이터 요약</div>
              <div class="k-big">조사기관 {n_orgs:,}곳</div>
              <div class="k-sub">{dmin:%Y-%m-%d} ~ {dmax:%Y-%m-%d} · 라벨 {n_labels}개</div>
              <div style="margin-top:10px" class="k-sub">σ = {sigma:.1f}pp · 반감기 = {int(_qp_int("hl",7))}일</div>
            </div>
            """, unsafe_allow_html=True
        )

    with colC:
        if scenario_nowcast is not None and not scenario_nowcast.empty and party_a in scenario_nowcast.index and party_b in scenario_nowcast.index:
            spread = float(scenario_nowcast[party_a] - scenario_nowcast[party_b])
            winA = phi(spread / max(1e-6, float(sigma)))
            src = "시나리오" if ('sc_on' in locals() and sc_on) else "nowcast"
            st.markdown(
                f"""
                <div class="k-card">
                  <div class="k-title">헤드투헤드 ({src})</div>
                  <div class="k-big">{party_a} vs {party_b}</div>
                  <div class="k-sub">스프레드 {spread:.1f}pp → {party_a} 승률 ≈ {winA:.1%}</div>
                </div>
                """, unsafe_allow_html=True
            )
        else:
            st.markdown('<div class="k-card"><div class="k-title">헤드투헤드</div>대상이 부족합니다.</div>', unsafe_allow_html=True)

    with colR:
        if not preds_sorted.empty and 'mc_win_prob' in preds_sorted.columns:
            viz_mode = st.radio("시각화 방식", ["도넛", "와플"], horizontal=True, key="overview_viz")
            topn = min(6, len(preds_sorted))
            data_top = preds_sorted.head(topn).copy()
            if viz_mode == "도넛":
                chart = donut_chart_df(
                    data_top.rename(columns={"정당":"라벨"}),
                    label_col="라벨", prob_col="mc_win_prob",
                    title="정당별 당선 확률",
                    topn=topn, hide_numbers=hide_numbers,
                    min_label=4.0, color_map=PARTY_COLOR_MAP
                )
                if chart is not None:
                    st.altair_chart(chart, use_container_width=True, theme=None)
            else:
                rows = []
                for _, r in data_top.iterrows():
                    fill = int(round(float(r.get('mc_win_prob', 0.0)) * 100))
                    for i in range(100):
                        rows.append({'정당': r['정당'], '칸': i, '채움': 1 if i < fill else 0})
                waffle = pd.DataFrame(rows)
                if not waffle.empty:
                    waffle['row'] = (waffle['칸'] // 10).astype(int)
                    waffle['col'] = (waffle['칸'] % 10).astype(int)
                    chart = (
                        alt.Chart(waffle)
                        .mark_rect()
                        .encode(
                            x=alt.X('col:O', axis=None),
                            y=alt.Y('row:O', sort='descending', axis=None),
                            color=alt.Color('채움:N', scale=alt.Scale(domain=[0,1], range=['#2a3654', '#2E6BFF']), legend=None),
                            facet=alt.Facet('정당:N', columns=topn)
                        )
                        .properties(height=160)
                        .configure_view(stroke=None, fill='#111827')
                    )
                    st.altair_chart(chart, use_container_width=True, theme=None)
        else:
            st.markdown('<div class="k-card"><div class="k-title">TOP 승률</div>표시할 데이터가 없습니다.</div>', unsafe_allow_html=True)

# ------------------ 예측표 ------------------
with tab_table:
    st.subheader("예측 표")
    if preds_sorted is None or preds_sorted.empty:
        st.info("예측 결과가 비어 있습니다.")
    else:
        candidates_raw = ['mc_win_prob','mc_p50','nowcast_pp','predicted_vote_ml','predicted_vote_gpt']
        sort_candidates = [c for c in candidates_raw if c in preds.columns]
        label_list = [SORT_LABELS.get(c, c) for c in sort_candidates]
        inv_map = {SORT_LABELS.get(c, c): c for c in sort_candidates}
        metric_label = st.selectbox("정렬 기준(내림차순)", label_list, index=0)
        metric = inv_map[metric_label]

        secondary = []
        if metric == 'mc_win_prob':
            for cand in ['mc_p50','nowcast_pp','predicted_vote_ml','predicted_vote_gpt']:
                if cand in preds.columns: secondary.append(cand)
        by_cols = [metric] + secondary
        preds_sorted2 = preds.sort_values(by=by_cols, ascending=[False]*len(by_cols), na_position='last').reset_index(drop=True)
        preds_sorted2.insert(0, '순위', range(1, len(preds_sorted2)+1))

        cfg = {}
        try:
            cfg['mc_win_prob'] = st.column_config.ProgressColumn(COLUMN_LABELS['mc_win_prob'], format="%.0f%%", min_value=0.0, max_value=1.0)
        except Exception:
            pass
        for c in ['nowcast_pp','predicted_vote_gpt','predicted_vote_ml','mc_p50','mc_p50_lo','mc_p50_hi','mc_p80_lo','mc_p80_hi']:
            if c in preds_sorted2.columns:
                cfg[c] = st.column_config.NumberColumn(COLUMN_LABELS.get(c, c), format="%.1f%%")
        cfg.setdefault('순위', st.column_config.Column(COLUMN_LABELS['순위']))
        cfg.setdefault('정당', st.column_config.Column(COLUMN_LABELS['정당']))

        show_df = preds_sorted2.copy()
        if hide_numbers:
            for c in list(cfg.keys()):
                if c not in ['mc_win_prob','순위','정당'] and c in show_df.columns:
                    show_df[c] = None

        st.dataframe(show_df, use_container_width=True, column_config=cfg)
        st.download_button(
            "CSV 다운로드",
            preds_sorted2.to_csv(index=False).encode("utf-8-sig"),
            file_name=f"prediction_{pd.Timestamp.now():%Y%m%d_%H%M}.csv",
            mime="text/csv",
        )

# ------------------ 추세 ------------------
with tab_trend:
    st.subheader("당선확률 추세 (주간 · 퍼센트)")
    try:
        trend = prob_trend_last_30days(
            polls_long=polls_long,
            election_date=pd.to_datetime(election_date),
            party_a=party_a, party_b=party_b,
            window=window, sigma=sigma
        )
        if trend.empty:
            st.info("최근 30일 범위 내에 두 대상 데이터가 부족합니다.")
        else:
            party_cols = [c for c in trend.columns if c != '날짜']
            trend['주'] = trend['날짜'].dt.to_period('W-MON').apply(lambda r: r.start_time)
            weekly = trend.groupby('주', as_index=False)[party_cols].mean()
            weekly_melt = weekly.melt(id_vars=['주'], var_name='정당', value_name='확률')
            weekly_melt['확률_퍼센트'] = (weekly_melt['확률'] * 100).round(1)

            chart = (
                alt.Chart(weekly_melt)
                .mark_line(point=True)
                .encode(
                    x=alt.X('주:T', title='주(월 시작)'),
                    y=alt.Y('확률_퍼센트:Q', title='당선확률(%)', scale=alt.Scale(domain=[0, 100])),
                    color='정당:N',
                    tooltip=[alt.Tooltip('주:T', title='주(월 시작)'), alt.Tooltip('정당:N'), alt.Tooltip('확률_퍼센트:Q', title='당선확률(%)', format='.1f')]
                )
                .properties(height=320)
                .configure_axis(gridColor='#2a3654', labelColor='#E8EDF5', titleColor='#E8EDF5')
                .configure_legend(labelColor='#E8EDF5', titleColor='#E8EDF5')
                .configure_view(stroke=None, fill='#111827')
            )
            st.altair_chart(chart, use_container_width=True, theme=None)
            st.caption(f"σ={sigma:.1f}pp, 롤링={_qp_int('win',7)}일 · 최근 30일 일별 확률을 주간 평균으로 집계(%)")
    except Exception:
        st.error("추세선 계산 중 오류가 발생했습니다.")
        with st.expander("자세한 오류 보기"):
            st.code("".join(traceback.format_exc()))

# ------------------ 매트릭스 ------------------
with tab_matrix:
    st.subheader("정당 간 헤드투헤드 승률")
    if scenario_nowcast is None or scenario_nowcast.empty:
        st.info("nowcast 데이터가 없어 매트릭스를 계산할 수 없습니다.")
    else:
        mat = pairwise_matrix(scenario_nowcast, sigma_pp=float(sigma)).astype(float)

        def _rank(p):
            return BALLOT_ORDER.index(p) if p in BALLOT_ORDER else (10_000 + hash(p) % 1000)
        order_list = sorted(mat.index.tolist(), key=_rank)
        mat = mat.loc[order_list, order_list]

        c1, c2, c3 = st.columns([1,1,1])
        with c1: cell_h = st.slider("셀 높이", 28, 80, 48, 2)
        with c2: cell_w = st.slider("셀 너비", 40, 160, 100, 2)
        with c3: axis_angle = st.radio("라벨 각도", ["0°","-45°"], index=1, horizontal=True)
        show_numbers = st.checkbox("셀에 % 표시", value=True)
        hi_contrast  = st.toggle("고대비 색상", value=False)

        melt = (
            mat.reset_index()
               .melt(id_vars='index', var_name='상대', value_name='승률')
               .rename(columns={'index':'정당'})
               .dropna(subset=['승률'])
        )
        if melt.empty:
            st.warning("표시할 값이 없습니다.")
            st.stop()
        melt['승률(%)'] = (melt['승률'] * 100).astype(float).round(1)

        n = len(order_list)
        W = max(160, int(cell_w * n))
        H = max(120, int(cell_h * n))
        palette = ['#b91c1c', '#0b1220', '#16a34a'] if hi_contrast else ['#ef4444', '#9ca3af', '#22c55e']
        angle_deg = 315 if axis_angle in ("-45°", "−45°") else 0

        FIELD, FQ = "승률(%)", "승률(%):Q"
        base = alt.Chart(melt)

        heat = (
            base.mark_rect(stroke=None)
            .encode(
                x=alt.X('상대:N', sort=order_list,
                        axis=alt.Axis(title=None, labelAngle=angle_deg, ticks=False, domain=False,
                                      labelColor='#111111', labelFontWeight='bold', labelFontSize=12)),
                y=alt.Y('정당:N', sort=order_list,
                        axis=alt.Axis(title=None, ticks=False, domain=False,
                                      labelColor='#111111', labelFontWeight='bold', labelFontSize=12)),
                color=alt.Color(FQ, scale=alt.Scale(domain=[0,50,100], range=palette), legend=None),
                tooltip=[alt.Tooltip('정당:N'), alt.Tooltip('상대:N'), alt.Tooltip(FQ, title='승률(%)', format='.1f')],
            )
            .properties(width=W, height=H)
        )

        chart = heat
        if show_numbers:
            txt = (
                base.mark_text(size=13, fontWeight='bold')
                .encode(
                    x='상대:N', y='정당:N',
                    text=alt.Text(FQ, format='.1f'),
                    color=alt.condition(
                        f'(datum["{FIELD}"] >= 60) || (datum["{FIELD}"] <= 40)',
                        alt.value('#ffffff'), alt.value('#111827')
                    )
                )
            )
            chart = alt.layer(heat, txt)

        chart = chart.configure_view(stroke=None, fill='#111827').configure_axis(grid=False)
        st.altair_chart(chart, use_container_width=True, theme=None)
        st.caption("행(A) vs 열(B): A가 B를 이길 확률(%) — 당명 라벨은 검정색")

# ------------------ 후보 ------------------
with tab_cand:
    st.subheader("후보 예측(정당→후보 전이)")
    st.caption("전이행렬 파일이 없으면 자동 후보명 맵으로 전이행렬을 구성합니다. (정당 100%→해당 후보)")

    auto_map_on    = st.toggle("정당 기반 자동 후보명 사용", value=True)
    exclude_others = st.toggle("기타/군소/무소속 제외(후보 예측에서 제거)", value=True)
    fast_mode      = st.toggle("⚡ 고속 모드(시뮬레이션 축소)", value=fast_mode_global)
    merge_dup      = st.toggle("동일 후보명 자동 합치기", value=True, help="전이행렬에서 같은 후보명으로 매핑된 여러 행을 합쳐 승률 왜곡 방지")
    n_sims = 2000 if fast_mode else 6000
    st.caption(f"시뮬레이션 횟수: {n_sims:,}회")

    if "cand_map" not in st.session_state:
        st.session_state["cand_map"] = {}

    parties_all = preds['정당'].astype(str).tolist() if not preds.empty else party_list
    parties_for_editor = [p for p in parties_all if not re.search(OTHERS_REGEX, str(p))] if exclude_others else parties_all

    def _sanitize_cand(name, party):
        s = str(name).strip()
        if s == "" or s.isdigit():
            s = CANDIDATE_PRESET.get(party, f"{party} 후보")
        return s

    cols_btn = st.columns([1,3])
    with cols_btn[0]:
        if st.button("프리셋 자동 채움"):
            for p in parties_for_editor:
                st.session_state["cand_map"][p] = CANDIDATE_PRESET.get(p, f"{p} 후보")
            st.rerun()

    editor_rows, cols = [], st.columns(min(len(parties_for_editor), 3) or 1)
    for i, p in enumerate(parties_for_editor):
        default_name = st.session_state["cand_map"].get(p, CANDIDATE_PRESET.get(p, f"{p} 후보"))
        with cols[i % len(cols)]:
            typed = st.text_input(f"{p} 후보명", value=str(default_name), key=f"cand_{p}")
        fixed = _sanitize_cand(typed, p)
        st.session_state["cand_map"][p] = fixed
        editor_rows.append({"정당": p, "후보": fixed})
    editor_df = pd.DataFrame(editor_rows)
    editor_df['후보'] = editor_df['후보'].astype(str)

    transfer = None
    with st.expander("고급: 전이행렬/후보명 매핑 업로드", expanded=False):
        tm_file = st.file_uploader("전이행렬(.csv/.xlsx) — long['후보','정당','비중'] 또는 ['후보','정당']", type=["csv","xlsx","xls"], key="transfer_uploader")
        map_file = st.file_uploader("후보명 매핑(.csv) — columns: (후보,표시명) 또는 (id,name)", type=["csv"], key="cand_name_map_uploader")

    # 후보명 매핑 CSV
    name_map = st.session_state.get("cand_name_map", {})
    if map_file is not None:
        try:
            df_map = pd.read_csv(map_file)
            if {"후보","표시명"}.issubset(df_map.columns):
                m = dict(zip(df_map["후보"].astype(str), df_map["표시명"].astype(str)))
            elif {"id","name"}.issubset(df_map.columns):
                m = dict(zip(df_map["id"].astype(str), df_map["name"].astype(str)))
            else:
                st.error("매핑 CSV 컬럼을 확인하세요. (후보,표시명) 또는 (id,name)")
                m = {}
            name_map = {str(k): str(v) for k, v in m.items()}
            st.session_state["cand_name_map"] = name_map
            st.success(f"후보명 매핑 {len(name_map):,}건 적용 준비 완료")
        except Exception as e:
            st.error("매핑 CSV 읽기 오류")
            st.code(str(e))

    # 전이행렬 로드
    if tm_file is not None:
        suffix2 = os.path.splitext(tm_file.name)[1]
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix2) as tmp2:
            tmp2.write(tm_file.getbuffer()); tm_path = tmp2.name
        try:
            transfer = load_transfer_matrix(tm_path, party_cols=parties_for_editor)
            transfer.index = transfer.index.astype(str)

            # 기타/군소 제외
            if exclude_others:
                keep_cols = [c for c in transfer.columns if not re.search(OTHERS_REGEX, str(c))]
                transfer = transfer.loc[:, keep_cols]
                transfer = transfer.loc[(transfer.sum(axis=1) > 0)]

            # 숫자 라벨이면 정당 프리셋으로 후보명 치환 + 중복 합치기
            try:
                idx_str = transfer.index.astype(str)
                looks_numeric_ratio = (idx_str.str.fullmatch(r"\d+").fillna(False)).mean()
                if looks_numeric_ratio >= 0.5:
                    parties_cols = list(transfer.columns)
                    row_argmax = np.argmax(transfer.values, axis=1) if transfer.values.size else np.zeros(len(transfer), dtype=int)
                    new_labels, used_count = [], {}
                    for i, k in enumerate(row_argmax):
                        party = parties_cols[int(k)] if parties_cols else ""
                        nm = st.session_state["cand_map"].get(party, CANDIDATE_PRESET.get(party, f"{party} 후보"))
                        if nm in used_count: used_count[nm] += 1; nm = f"{nm}_{used_count[nm]}"
                        else: used_count[nm] = 1
                        new_labels.append(str(nm))
                    transfer.index = pd.Index(new_labels, name="후보")
                    if merge_dup:
                        transfer = transfer.groupby(level=0, sort=False).sum()
                    st.info("숫자형 후보 라벨을 후보명으로 치환했습니다.")
            except Exception:
                pass

            st.success("업로드한 전이행렬을 적용했습니다.")
        except Exception:
            st.error("전이행렬 처리 중 오류가 발생했습니다.")
            with st.expander("자세한 오류 보기"):
                st.code("".join(traceback.format_exc()))
        finally:
            try: os.unlink(tm_path)
            except: pass

    # 전이행렬이 없으면 자동 구성(정당 100% → 후보)
    if transfer is None and auto_map_on:
        base = editor_df.assign(비중=1.0)
        transfer = base.pivot_table(index='후보', columns='정당', values='비중', aggfunc='sum').reindex(columns=parties_for_editor, fill_value=0.0)
        transfer.index = transfer.index.astype(str)
        st.info("자동 후보명 맵으로 전이행렬을 구성했습니다.")
        st.dataframe(editor_df, use_container_width=True)
        st.download_button("후보 맵 CSV 다운로드(후보,정당,비중)",
                           base[['후보','정당','비중']].to_csv(index=False).encode("utf-8-sig"),
                           file_name=f"candidate_map_{pd.Timestamp.now():%Y%m%d_%H%M}.csv", mime="text/csv")

    # ===== 시뮬레이션 =====
    if transfer is not None and not preds.empty and 'nowcast_pp' in preds.columns:
        preds_for_cand = preds.copy()
        if exclude_others:
            preds_for_cand = preds_for_cand[~preds_for_cand['정당'].astype(str).str.contains(OTHERS_REGEX, na=False)]

        series_base = preds_for_cand.set_index('정당')['nowcast_pp'].astype(float).fillna(0.0)
        series_use  = apply_scenario(series_base, deltas, keep_total=True) if ('sc_on' in locals() and sc_on) else series_base

        # 공통 정당 체크 + 행 정규화
        common = series_use.index.intersection(transfer.columns)
        if len(common) < 2:
            st.warning(f"후보 시뮬레이션에 사용할 정당이 {len(common)}개입니다. "
                       f"exclude_others 토글/전이행렬 컬럼/라벨을 확인하세요. (공통 정당: {list(common)})")

        transfer2 = transfer.loc[:, common].copy()
        row_sum = transfer2.sum(axis=1)
        transfer2 = transfer2.div(row_sum.where(row_sum > 0, 1), axis=0)

        if series_use.empty or transfer2.empty:
            st.warning("후보 시뮬레이션에 사용할 정당이 없습니다. (기타/군소 제외/시나리오 설정 확인)")
        else:
            cand_df = predict_candidates_via_transfer(series_use.loc[common], transfer2, sigma_pp=float(sigma), n_sims=n_sims)

            # 후보 라벨 확정
            if '후보' not in cand_df.columns:
                cand_df = cand_df.reset_index()
                if 'index' in cand_df.columns and '후보' not in cand_df.columns:
                    cand_df = cand_df.rename(columns={'index': '후보'})
            cand_df['후보'] = cand_df['후보'].astype(str).fillna('').str.strip()

            # 매핑 CSV 적용
            if name_map:
                cand_df['후보'] = cand_df['후보'].map(lambda x: name_map.get(x, x))

            # 숫자 컬럼 정리
            for c in ['cand_win_prob','cand_p50','cand_p50_lo','cand_p50_hi','cand_p80_lo','cand_p80_hi']:
                if c in cand_df.columns:
                    cand_df[c] = pd.to_numeric(cand_df[c], errors='coerce')

            # === 표시 스케일 통일 ===
            prob = pd.to_numeric(cand_df['cand_win_prob'], errors='coerce').fillna(0.0).clip(0,1)
            view = cand_df.copy()
            view['cand_win_prob'] = prob                 # 0~1 (프로그레스)
            view['승률(%)'] = (prob * 100).round(1)       # 숫자 %

            cfg = {}
            try:
                cfg['cand_win_prob'] = st.column_config.ProgressColumn("승률(모의실험)", min_value=0.0, max_value=1.0, format="%.0f%%")
            except Exception:
                pass
            cfg['후보'] = st.column_config.TextColumn("후보", width="medium")
            cfg['승률(%)'] = st.column_config.NumberColumn("승률(%)", format="%.1f%%")
            for c, lab in [('cand_p50','예상 득표율(중앙값)'),('cand_p50_lo','p50 하한'),('cand_p50_hi','p50 상한'),
                           ('cand_p80_lo','p80 하한'),('cand_p80_hi','p80 상한')]:
                if c in view.columns:
                    cfg[c] = st.column_config.NumberColumn(lab, format="%.1f%%")

            if hide_numbers:
                for c in ['승률(%)','cand_p50','cand_p50_lo','cand_p50_hi','cand_p80_lo','cand_p80_hi']:
                    if c in view.columns: view[c] = None

            cols_for_table = ['후보','승률(%)','cand_win_prob']
            for c in ['cand_p50','cand_p50_lo','cand_p50_hi','cand_p80_lo','cand_p80_hi']:
                if c in view.columns: cols_for_table.append(c)

            st.dataframe(view[cols_for_table], use_container_width=True, column_config=cfg)

            cand_df_export = view.copy()
            st.download_button("후보 예측 CSV 다운로드",
                               cand_df_export.to_csv(index=False).encode("utf-8-sig"),
                               file_name=f"candidates_{pd.Timestamp.now():%Y%m%d_%H%M}.csv", mime="text/csv")

            st.markdown("#### 후보 승률(도넛)")
            donut_src = view.rename(columns={"cand_win_prob":"확률"})
            donut_src['라벨'] = view['후보']
            chart = donut_chart_df(donut_src, label_col="라벨", prob_col="확률",
                                   title="후보별 당선 확률", topn=8, hide_numbers=hide_numbers, min_label=4.0)
            if chart is not None:
                st.altair_chart(chart, use_container_width=True, theme=None)
    else:
        st.info("예측 결과/전이행렬이 준비되면 후보 탭이 활성화됩니다.")

# ===================== cleanup =====================
try: os.unlink(poll_path)
except: pass
