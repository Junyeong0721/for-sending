# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from math import erf, sqrt
from typing import Dict

# =========================
# 공통 유틸
# =========================
def _normalize_percent_series(s: pd.Series) -> pd.Series:
    """'12.3%', '12,3', '12.3pp' 등 → float(12.3)"""
    return pd.to_numeric(
        s.astype(str)
         .str.replace('%', '', regex=False)
         .str.replace('pp', '', regex=False)
         .str.replace(',', '', regex=False)
         .str.strip(),
        errors='coerce'
    )

# 정당/라벨 표준화 맵
_CANON_MAP: Dict[str, str] = {
    '국민의힘': '국민의힘', '한나라당': '국민의힘', '새누리당': '국민의힘', '자유한국당': '국민의힘',
    '더불어민주당': '더불어민주당', '더민주': '더불어민주당', '민주당': '더불어민주당',
    '정의당': '정의당',
    '진보당': '진보당',
    '개혁신당': '개혁신당',
    '민주노동당': '정의당',  # 사용자 요청: 민노당은 정의당 계열로 표준화
    # 필요시 추가: '통합진보당': '정의당',
}

def _canon_party(x) -> str:
    if pd.isna(x):
        return None
    s = str(x).strip()
    return _CANON_MAP.get(s, s)

# 후보→정당 매핑(필요시)
_CAND_TO_PARTY_20: Dict[str, str] = {
    # 예: '홍길동': '국민의힘', '김철수': '더불어민주당'
}

# =========================
# 과거 데이터 로더
# =========================
def _load_polls_hist_flexible(poll_path: str) -> pd.DataFrame:
    """과거 여론조사: 첫 시트 wide → long. 필수: '기관','날짜'."""
    df = pd.read_excel(poll_path) if poll_path.lower().endswith(('.xlsx', '.xls')) else pd.read_csv(poll_path, encoding='utf-8')
    df.columns = df.columns.astype(str).str.strip()

    need = {'기관', '날짜'}
    if not need.issubset(df.columns):
        raise ValueError("과거 여론조사 파일에는 '기관','날짜' 컬럼이 필요합니다.")

    party_cols = [c for c in df.columns if c not in ['기관', '날짜']]
    long = df.melt(id_vars=['기관','날짜'], value_vars=party_cols,
                   var_name='정당', value_name='지지율_raw')
    long['지지율'] = _normalize_percent_series(long['지지율_raw'])
    long['날짜'] = pd.to_datetime(long['날짜'], errors='coerce')
    long['정당'] = long['정당'].map(_canon_party)
    long = long.dropna(subset=['지지율', '날짜'])
    return long[['기관','날짜','정당','지지율']]

def _load_results_flexible(res_path: str) -> pd.DataFrame:
    """
    과거 대선 결과: 시트/헤더가 제각각이어도
    - 정당(or 후보) + 득표율(숫자/%) 한 쌍을 자동 탐지해 '정당','vote_actual' 로 표준화.
    """
    xl = pd.ExcelFile(res_path)
    found = []

    for sheet in xl.sheet_names:
        for header in range(0, 5):
            try:
                df0 = xl.parse(sheet, header=header)
            except Exception:
                continue
            if df0 is None or df0.empty:
                continue

            df0.columns = df0.columns.map(lambda x: str(x).strip())
            df0 = df0.dropna(how='all').dropna(axis=1, how='all')
            if df0.empty:
                continue

            party_col = next((c for c in df0.columns if '정당' in c), None)
            cand_col  = next((c for c in df0.columns if '후보' in c), None)
            vote_col = next((c for c in df0.columns if '득표' in c or '%' in c), None)
            if vote_col is None:
                num_cols = [c for c in df0.columns if pd.to_numeric(df0[c], errors='coerce').notna().mean() > 0.5]
                vote_col = num_cols[0] if num_cols else None

            if party_col is None and cand_col is None:
                obj_cols = [c for c in df0.columns if df0[c].dtype == object]
                party_col = obj_cols[0] if obj_cols else None

            if vote_col is None or (party_col is None and cand_col is None):
                continue

            who_col = party_col if party_col is not None else cand_col
            tmp = df0[[who_col, vote_col]].copy()
            tmp.columns = ['who', '득표율']
            tmp['득표율'] = _normalize_percent_series(tmp['득표율'])
            tmp = tmp.dropna(subset=['득표율']).copy()

            if party_col is not None:
                tmp['정당'] = tmp['who'].astype(str).map(_canon_party)
            else:
                tmp['정당'] = (
                    tmp['who'].map(_CAND_TO_PARTY_20).fillna(tmp['who']).map(_canon_party)
                )

            tmp = tmp[['정당', '득표율']].dropna(subset=['정당'])
            if not tmp.empty:
                found.append(tmp)
                break

    if not found:
        raise ValueError("과거 대선 결과.xlsx에서 유효한 '정당/후보' + '득표율' 표를 찾지 못했습니다. "
                         "첫 시트에 '정당','득표율' 두 컬럼으로 간단히 만들어 주세요.")

    res = pd.concat(found, ignore_index=True)
    res = res.groupby('정당', as_index=False)['득표율'].mean()
    res = res.rename(columns={'득표율': 'vote_actual'})
    return res

def load_historical_train(poll_path: str, res_path: str):
    """학습에 쓸 과거 여론조사(long)와 과거 득표율(정당별)"""
    polls_long = _load_polls_hist_flexible(poll_path)
    votes = _load_results_flexible(res_path)
    return polls_long, votes

# =========================
# 현재(업로드) 데이터 로더
# =========================
def load_current_poll(poll_path: str) -> pd.DataFrame:
    """업로드 파일(.csv/.xlsx) wide→long 표준화. 필수: '기관','날짜' + 정당/후보 열들."""
    df = pd.read_excel(poll_path) if poll_path.lower().endswith(('.xlsx', '.xls')) else pd.read_csv(poll_path, encoding='utf-8')
    df.columns = df.columns.astype(str).str.strip()

    need = {'기관', '날짜'}
    if not need.issubset(df.columns):
        raise ValueError("최신 여론조사 파일에는 '기관','날짜' 컬럼이 필요합니다.")

    party_cols = [c for c in df.columns if c not in ['기관', '날짜']]
    long = df.melt(id_vars=['기관','날짜'], value_vars=party_cols,
                   var_name='정당', value_name='지지율_raw')
    long['지지율'] = _normalize_percent_series(long['지지율_raw'])
    long['날짜'] = pd.to_datetime(long['날짜'], errors='coerce')
    long['정당'] = long['정당'].map(_canon_party)
    long = long.dropna(subset=['지지율', '날짜', '정당'])
    return long[['기관','날짜','정당','지지율']]

# =========================
# 특징량, 간단 예측, 확률 추세
# =========================
def _to_daynum(s: pd.Series) -> pd.Series:
    return (pd.to_datetime(s) - pd.Timestamp("1970-01-01")) / pd.Timedelta(days=1)

def compute_features(polls_long: pd.DataFrame) -> pd.DataFrame:
    """입력: ['기관','날짜','정당','지지율'] → 출력: ['정당','poll_mean','poll_std','poll_trend']"""
    cols_needed = ['기관','날짜','정당','지지율']
    if polls_long is None or polls_long.empty or not set(cols_needed).issubset(polls_long.columns):
        return pd.DataFrame(columns=['정당','poll_mean','poll_std','poll_trend'])

    df = polls_long.copy()
    df['날짜'] = pd.to_datetime(df['날짜'], errors='coerce')
    df = df.dropna(subset=['정당','날짜','지지율'])
    if df.empty:
        return pd.DataFrame(columns=['정당','poll_mean','poll_std','poll_trend'])

    feats = (
        df.groupby('정당', as_index=False)['지지율']
          .agg(poll_mean='mean', poll_std='std')
    )

    def slope(sub):
        x = _to_daynum(sub['날짜']).astype(float).to_numpy()
        y = sub['지지율'].astype(float).to_numpy()
        if len(x) < 2:
            return 0.0
        xm, ym = x.mean(), y.mean()
        denom = ((x - xm) ** 2).sum()
        if denom == 0:
            return 0.0
        return float(((x - xm) * (y - ym)).sum() / denom)

    trend = (
        df.groupby('정당', as_index=False)
          .apply(lambda g: pd.Series({'poll_trend': slope(g)}))
    )
    out = pd.merge(feats, trend, on='정당', how='outer')
    for c in ['poll_mean','poll_std','poll_trend']:
        if c not in out.columns:
            out[c] = 0.0
    out[['poll_mean','poll_std','poll_trend']] = out[['poll_mean','poll_std','poll_trend']].astype(float).fillna(0.0)
    out = out.drop_duplicates(subset=['정당']).reset_index(drop=True)
    return out[['정당','poll_mean','poll_std','poll_trend']]

def build_prompt(hist_df: pd.DataFrame, curr_feats: pd.DataFrame) -> str:
    msg = ["[과거 학습 요약]"]
    if hist_df is not None and not hist_df.empty:
        for _, r in hist_df[['정당','poll_mean','poll_std','poll_trend','vote_actual']].fillna(0).iterrows():
            msg.append(f"- {r['정당']}: mean={r['poll_mean']:.1f}, std={r['poll_std']:.1f}, trend={r['poll_trend']:.3f}, actual={r['vote_actual']:.1f}")
    else:
        msg.append("- (데이터 없음)")
    msg.append("\n[현재 특징량]")
    for _, r in curr_feats[['정당','poll_mean','poll_std','poll_trend']].iterrows():
        msg.append(f"- {r['정당']}: mean={r['poll_mean']:.1f}, std={r['poll_std']:.1f}, trend={r['poll_trend']:.3f}")
    return "\n".join(msg)

def predict_with_gpt_or_fallback(prompt: str, curr_feats: pd.DataFrame) -> Dict[str, float]:
    """현재는 poll_mean을 0~100 정규화한 간단 휴리스틱 예측."""
    if curr_feats is None or curr_feats.empty:
        return {}
    df = curr_feats.copy()
    df['poll_mean'] = df['poll_mean'].clip(lower=0).fillna(0.0)
    s = df['poll_mean'].sum()
    if s <= 0:
        v = 100.0 / len(df)
        return {p: v for p in df['정당']}
    return {p: float(100.0 * m / s) for p, m in zip(df['정당'], df['poll_mean'])}

def _phi(z: float) -> float:
    return 0.5 * (1.0 + erf(z / sqrt(2.0)))

def prob_trend_last_30days(polls_long: pd.DataFrame,
                           election_date: pd.Timestamp,
                           party_a: str, party_b: str,
                           window: int = 7, sigma: float = 2.5) -> pd.DataFrame:
    """
    선거일 기준 -30일 ~ -1일 데이터에서 날짜별 롤링 평균으로 스프레드(A-B)를 계산하고 Φ(spread/σ)로 승리확률 추정.
    반환: ['날짜', party_a, party_b]
    """
    if polls_long is None or polls_long.empty:
        return pd.DataFrame(columns=['날짜', party_a, party_b])

    end = pd.to_datetime(election_date) - pd.Timedelta(days=1)
    start = end - pd.Timedelta(days=29)
    df = polls_long[(polls_long['날짜'] >= start) & (polls_long['날짜'] <= end)].copy()
    if df.empty:
        return pd.DataFrame(columns=['날짜', party_a, party_b])

    df = df[df['정당'].isin([party_a, party_b])]
    if df.empty:
        return pd.DataFrame(columns=['날짜', party_a, party_b])

    day_party = (
        df.groupby(['날짜','정당'], as_index=False)['지지율'].mean()
        .pivot(index='날짜', columns='정당', values='지지율')
        .sort_index()
    )

    roll = day_party.rolling(window=window, min_periods=max(1, window//2)).mean()

    for c in [party_a, party_b]:
        if c not in roll.columns:
            roll[c] = np.nan

    spread = roll[party_a].fillna(method='ffill') - roll[party_b].fillna(method='ffill')
    prob_a = spread.apply(lambda x: _phi(x / max(1e-6, float(sigma))))
    prob_b = 1.0 - prob_a

    out = pd.DataFrame({'날짜': roll.index, party_a: prob_a.values, party_b: prob_b.values}).dropna(subset=[party_a, party_b])
    return out.reset_index(drop=True)

# =========================
# 후보 전이행렬 로더 (long/wide + 2컬럼 매핑 지원)
# =========================
def load_transfer_matrix(path: str, party_cols) -> pd.DataFrame:
    """
    입력:
      A1) long: [후보, 정당, 비중]  (비중 0~1)
      A2) mapping: [후보, 정당]     (비중=1.0 가정)
      B)  wide: 행=후보, 열=정당, 값=비중
    반환: index=후보, columns=party_cols.
          각 정당 열의 합이 >0이면 1로 정규화.
    """
    import os
    ext = os.path.splitext(path)[1].lower()
    df = pd.read_excel(path) if ext in ('.xlsx', '.xls') else pd.read_csv(path, encoding='utf-8')
    df.columns = df.columns.astype(str).str.strip()

    if set(['후보','정당','비중']).issubset(df.columns) or set(['후보','정당']).issubset(df.columns):
        if '비중' not in df.columns:
            df['비중'] = 1.0  # 매핑만 있으면 자기 정당 100% 가정
        df = df[['후보','정당','비중']].copy()
        df['정당'] = df['정당'].map(_canon_party)
        df['비중'] = pd.to_numeric(df['비중'], errors='coerce').fillna(0.0).clip(0.0, 1.0)
        wide = (df.pivot_table(index='후보', columns='정당', values='비중', aggfunc='sum')
                  .fillna(0.0))
    else:
        # wide 형식
        if '후보' in df.columns:
            df = df.set_index('후보')
        wide = df.apply(pd.to_numeric, errors='coerce').fillna(0.0)

    # 필요한 정당 컬럼 보강/정렬
    for p in party_cols:
        if p not in wide.columns:
            wide[p] = 0.0
    wide = wide[party_cols]

    # 각 정당 열 합 1로 정규화(>0인 열에 한해)
    for p in party_cols:
        s = wide[p].sum()
        if s > 0:
            wide[p] = wide[p] / s
    return wide
