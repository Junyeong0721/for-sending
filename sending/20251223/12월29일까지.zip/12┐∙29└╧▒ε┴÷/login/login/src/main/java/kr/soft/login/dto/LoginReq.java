package kr.soft.login.dto;

import lombok.Data;

@Data
public class LoginReq {

    private String userId;
    private String userPw;

}
