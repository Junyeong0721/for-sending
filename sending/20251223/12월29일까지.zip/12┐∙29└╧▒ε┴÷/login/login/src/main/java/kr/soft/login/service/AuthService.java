package kr.soft.login.service;

import kr.soft.login.config.jwt.JwtTokenProvider;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class AuthService {


    @Autowired
    private JwtTokenProvider jwtTokenProvider;
    @Autowired
    private RedisTokenService redisTokenService;
    @Autowired
    private BCryptPasswordEncoder encoder;



    // ✅ 로그인 처리

    /**
     * @param ( 사용자 ID, PW 필요 ) - 로그인 구분 용도
     * @return Token 정보
     */
    public String login(String id, String pw) {

        /**************
         * ✅ DB 유효성 검사 ( 아이디, 비밀번호 체크 )
         ***************/
        if(!id.equals("super")) {
            return null;
        }

        if(!pw.equals("1234")) {
            return null;
        }



        /**************
         * ✅ JWT 생성
         ***************/

        //1. 더미 데이터 생성
        id = "super";
        long idx = 1;

        //2. JWT 토큰 만들기
        String accessToken = jwtTokenProvider.createAccessToken(idx, id);

        
        
        /**************
         * ✅ REDIS 저장하기
         ***************/

        // ✅ UNIQUE이면 무엇이가든 가능
        //3. Redis 등록 (access:userId 형태)
        redisTokenService.saveAccessToken(id, accessToken);


        return accessToken;
    }


}