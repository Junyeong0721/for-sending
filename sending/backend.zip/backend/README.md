# 충청남도 지역 가이드 AI — 웹 전용 (FastAPI + PWA)

## 실행
```bash
cd backend
python -m venv .venv
# Windows: .\.venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
브라우저: http://localhost:8000
