let map, markers = [], routeLine = null;
const el = (id)=>document.getElementById(id);
const API = (path)=> (window.APP_API || '/') + path.replace(/^\//,'');

async function search() {
  const region = el('region').value;
  const city = el('city') ? el('city').value : "";
  const q = el('q').value.trim();
  const cbs = Array.from(document.querySelectorAll('.chips input[type=checkbox]:checked')).map(x=>x.value);
  const sort = el('sort').value;
  const useExternal = el('useExternal').checked;
  const body = { region, city, q, categories: cbs, sort, use_external: useExternal };
  const res = await fetch(API('/api/search'), { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
  const data = await res.json();
  fillRegions(data.regions, region);
  renderList(data.results);
  renderMap(data.results.map(r => r.place).filter(p=>p.lat && p.lng));
}
function fillRegions(regions, selected){
  const sel = el('region');
  if (sel.options.length === 0) {
    regions.forEach(r => { const opt = document.createElement('option'); opt.value=r; opt.textContent=r; sel.appendChild(opt); });
    sel.value = selected || regions[0];
  }
}
async function loadCities() {
  const region = el('region').value || '충청남도';
  const sel = el('city');
  if (!sel) return;
  sel.innerHTML = `<option value="">시·군(전체)</option>`;
  try {
    const res = await fetch(API(`/api/regions/cities?region=${encodeURIComponent(region)}`));
    const data = await res.json();
    (data.cities || []).forEach(c => {
      const opt = document.createElement('option');
      opt.value = c; opt.textContent = c;
      sel.appendChild(opt);
    });
  } catch (e) {}
}
function renderList(results){
  const wrap = el('list'); wrap.innerHTML = '';
  results.forEach(({place, score, dist}) => {
    const card = document.createElement('div'); card.className='card';
    const km = (dist != null) ? ` · ${dist.toFixed(1)}km` : '';
    card.innerHTML = `<h4>${place.name}</h4>
      <div class="meta">${place.region} · ${place.category} · ★${place.rating}${km}</div>
      <div>${place.description || ''}</div>
      <div class="tags">${(place.tags||[]).map(t=>`#${t}`).join(' ')}</div>
      <button>경로 보기</button>`;
    card.querySelector('button').onclick = ()=> drawRouteFromCenter(place.lat, place.lng);
    wrap.appendChild(card);
  });
}
function initMap(){
  if (!map) {
    map = L.map('map').setView([36.8, 126.7], 9);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 18 }).addTo(map);
  }
}
function renderMap(places){
  initMap();
  markers.forEach(m => m.remove()); markers = [];
  if (routeLine) { routeLine.remove(); routeLine = null; }
  places.forEach(p => { const m=L.marker([p.lat,p.lng]).addTo(map).bindPopup(`<b>${p.name}</b><br/>${p.category} · ★${p.rating}`); markers.push(m); });
  if (places.length) { const g = new L.featureGroup(markers); map.fitBounds(g.getBounds().pad(0.2)); }
}
async function drawRouteFromCenter(lat, lng){
  initMap();
  const c = map.getCenter();
  const url = API(`/api/route_osrm?start_lat=${c.lat}&start_lng=${c.lng}&end_lat=${lat}&end_lng=${lng}`);
  const res = await fetch(url); const data = await res.json();
  if (routeLine) routeLine.remove();
  routeLine = L.polyline(data.coords).addTo(map);
  map.fitBounds(routeLine.getBounds().pad(0.2));
}
el('searchBtn').onclick = search;

// ===== AI Chat =====
async function sendChat(){
  const textarea = el('msg');
  const btn = el('ask');
  const message = (textarea.value || '').trim();
  if (!message) { textarea.focus(); return; }
  const region = el('region').value || null;
  const model = el('model').value;
  const out = el('answer');

  btn.disabled = true;
  btn.textContent = '전송 중…';
  out.textContent = '생각 중…';

  try {
    const res = await fetch(API('/api/chat'), {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({message, region, model})
    });
    if (!res.ok) {
      const text = await res.text();
      throw new Error('서버 오류: ' + text.slice(0, 200));
    }
    const data = await res.json();
    out.textContent = `[route: ${data.route}]\n` + (data.reply || '(응답 없음)');
  } catch (e) {
    out.textContent = '❗ 오류: ' + (e.message || e.toString()) + '\\n' +
                      'MIDM_BACKEND=mock 으로 실행 중인지, 또는 torch/transformers 설치 여부를 확인해 주세요.';
  } finally {
    btn.disabled = false;
    btn.textContent = '보내기';
  }
}

el('ask').addEventListener('click', sendChat);
el('msg').addEventListener('keydown', (e)=>{
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendChat();
  }
});

// ===== Init =====
window.addEventListener('load', async ()=>{
  await loadCities();
  await search();
});

el('region').addEventListener('change', async ()=>{
  await loadCities();
  await search();
});

const citySel = document.getElementById('city');
if (citySel) citySel.addEventListener('change', search);

// Ingest
el('upload').onclick = async ()=>{
  const f = el('file').files[0]; if (!f) return;
  el('upStatus').textContent = '업로드 중…';
  const fd = new FormData(); fd.append('file', f);
  const res = await fetch(API('/api/ingest'), { method:'POST', body: fd });
  const data = await res.json();
  el('upStatus').textContent = data.ok ? `추가 완료 (총 ${data.total}개)` : '실패';
  search();
};
