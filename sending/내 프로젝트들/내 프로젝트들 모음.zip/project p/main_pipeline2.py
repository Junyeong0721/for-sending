# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor

from election_utils2 import (
    load_historical_train,
    load_current_poll,
    compute_features,
    build_prompt,
    predict_with_gpt_or_fallback,
)

FEAT_COLS = ['poll_mean', 'poll_std', 'poll_trend']

def _ensure_feat_cols(df: pd.DataFrame, cols):
    if df is None:
        return pd.DataFrame(columns=['정당', *cols])
    out = df.copy()
    if '정당' not in out.columns:
        out['정당'] = pd.NA
    for c in cols:
        if c not in out.columns:
            out[c] = 0.0
    return out[['정당', *cols]] if set(['정당']).issubset(out.columns) else out

# ---------- Nowcast: 최근성 가중 평균 ----------
def _recency_weights(dates: pd.Series, half_life_days: float = 7.0) -> pd.Series:
    if dates.isna().all():
        return pd.Series(np.ones(len(dates)), index=dates.index)
    t0 = pd.to_datetime(dates).max()
    age = (t0 - pd.to_datetime(dates)).dt.total_seconds() / 86400.0
    w = np.power(0.5, np.clip(age, 0.0, None) / max(1e-6, float(half_life_days)))
    return pd.Series(w, index=dates.index)

def compute_nowcast_pp(polls_long: pd.DataFrame, half_life_days: float = 7.0) -> pd.Series:
    if polls_long is None or polls_long.empty:
        return pd.Series(dtype=float)
    df = polls_long.copy().dropna(subset=['정당', '날짜', '지지율'])
    if df.empty:
        return pd.Series(dtype=float)

    day_party = (
        df.groupby(['날짜', '정당'], as_index=False)['지지율']
          .mean()
          .rename(columns={'지지율': 'day_mean'})
    )
    day_party['w'] = _recency_weights(day_party['날짜'], half_life_days)
    agg = (
        day_party.groupby('정당', as_index=False)
                 .apply(lambda g: (g['day_mean'] * g['w']).sum() / max(1e-12, g['w'].sum()))
                 .rename(columns={None: 'nowcast_pp'})
    )
    agg.index = agg['정당']
    s = agg['nowcast_pp'].clip(lower=0.0)
    if s.sum() <= 0:
        s[:] = 100.0 / len(s)
    return s

# ---------- Monte Carlo: 간이 승률/분위 ----------
def monte_carlo_from_nowcast(nowcast: pd.Series,
                             sigma_pp: float = 2.5,
                             n_sims: int = 5000,
                             seed: int = 42):
    parties = list(nowcast.index)
    P = len(parties)
    means = nowcast.values.astype(float)
    means = 100.0 * means / means.sum() if means.sum() > 0 else np.full(P, 100.0 / max(P, 1))

    rng = np.random.default_rng(seed)
    sigma_indiv = max(0.1, float(sigma_pp) / np.sqrt(2.0))  # pp
    sims = rng.normal(loc=means, scale=sigma_indiv, size=(n_sims, P))
    sims = np.clip(sims, 0, None)
    row_sum = sims.sum(axis=1, keepdims=True)
    zero_rows = (row_sum <= 0)
    if np.any(zero_rows):
        sims[zero_rows, :] = 100.0 / P
        row_sum = sims.sum(axis=1, keepdims=True)
    sims = sims * (100.0 / row_sum)

    winners = sims.argmax(axis=1)
    counts = np.bincount(winners, minlength=P)
    win_prob = counts / float(n_sims)

    q50 = np.quantile(sims, 0.50, axis=0)
    q25 = np.quantile(sims, 0.25, axis=0)
    q75 = np.quantile(sims, 0.75, axis=0)
    q10 = np.quantile(sims, 0.10, axis=0)
    q90 = np.quantile(sims, 0.90, axis=0)

    to_dict = lambda arr: {p: float(v) for p, v in zip(parties, arr)}
    return (
        to_dict(win_prob),
        to_dict(q50),
        to_dict(q25), to_dict(q75),
        to_dict(q10), to_dict(q90),
    )

def _rf_intervals(model: RandomForestRegressor, X: pd.DataFrame):
    if not hasattr(model, "estimators_") or len(model.estimators_) == 0:
        n = len(X)
        z = pd.Series([np.nan] * n, index=X.index)
        return z, z, z, z
    preds = np.stack([est.predict(X) for est in model.estimators_], axis=1)
    q10 = np.quantile(preds, 0.10, axis=1)
    q25 = np.quantile(preds, 0.25, axis=1)
    q75 = np.quantile(preds, 0.75, axis=1)
    q90 = np.quantile(preds, 0.90, axis=1)
    return (
        pd.Series(q25, index=X.index),
        pd.Series(q75, index=X.index),
        pd.Series(q10, index=X.index),
        pd.Series(q90, index=X.index),
    )

def train_and_predict(poll_hist_path: str, res_hist_path: str, latest_poll_path: str,
                      sigma_pp: float = 2.5, n_sims: int = 5000, half_life_days: int = 7) -> pd.DataFrame:
    # 1) 과거 데이터 → 특징 → ML 학습
    polls_long, votes = load_historical_train(poll_hist_path, res_hist_path)

    hist_feats = compute_features(polls_long)
    hist_feats = _ensure_feat_cols(hist_feats, FEAT_COLS)

    hist = (
        pd.merge(hist_feats, votes, on='정당', how='inner')
        if not hist_feats.empty and votes is not None and not votes.empty
        else pd.DataFrame(columns=['정당', *FEAT_COLS, 'vote_actual'])
    )

    if not hist.empty and 'vote_actual' in hist.columns:
        hist = hist.dropna(subset=['vote_actual'])
        hist_X = hist[FEAT_COLS].astype(float) if not hist.empty else pd.DataFrame(columns=FEAT_COLS)
        hist_y = hist['vote_actual'].astype(float) if not hist.empty else pd.Series([], dtype=float)
    else:
        hist_X = pd.DataFrame(columns=FEAT_COLS)
        hist_y = pd.Series([], dtype=float)

    # 2) 최신 데이터 → 특징/nowcast
    current_long = load_current_poll(latest_poll_path)
    curr_feats = compute_features(current_long)
    curr_feats = _ensure_feat_cols(curr_feats, FEAT_COLS)

    nowcast = compute_nowcast_pp(current_long, half_life_days=half_life_days)

    if curr_feats is None or curr_feats.empty or '정당' not in curr_feats.columns:
        out = pd.DataFrame({'정당': nowcast.index if len(nowcast) else [], 'nowcast_pp': nowcast.values if len(nowcast) else []})
        for col in ['predicted_vote_gpt','predicted_vote_ml','ml_p50_lo','ml_p50_hi','ml_p80_lo','ml_p80_hi',
                    'mc_win_prob','mc_p50','mc_p50_lo','mc_p50_hi','mc_p80_lo','mc_p80_hi']:
            out[col] = pd.NA
        return out

    # 3) 휴리스틱 예측
    hist_for_prompt = hist[['정당', *FEAT_COLS, 'vote_actual']] if not hist.empty else pd.DataFrame()
    prompt = build_prompt(hist_for_prompt, curr_feats)
    gpt_out = predict_with_gpt_or_fallback(prompt, curr_feats)

    # 4) ML + 신뢰구간
    ml_pred = None
    p50_lo = p50_hi = p80_lo = p80_hi = None
    if not hist_X.empty and not curr_feats.empty and (set(hist['정당']) & set(curr_feats['정당'])):
        model = RandomForestRegressor(n_estimators=500, random_state=42)
        Xc = curr_feats[FEAT_COLS].astype(float)
        model.fit(hist_X, hist_y)
        ml_pred = model.predict(Xc)
        p50_lo, p50_hi, p80_lo, p80_hi = _rf_intervals(model, Xc)

    # 5) 몬테카를로 승률
    mc_win_prob = mc_p50 = mc_p50_lo = mc_p50_hi = mc_p80_lo = mc_p80_hi = {}
    if len(nowcast) >= 2:
        (mc_win_prob,
         mc_p50,
         mc_p50_lo, mc_p50_hi,
         mc_p80_lo, mc_p80_hi) = monte_carlo_from_nowcast(
            nowcast, sigma_pp=sigma_pp, n_sims=n_sims, seed=42
        )

    # 6) 결과 병합
    out = curr_feats[['정당']].copy()
    out['nowcast_pp'] = out['정당'].map(nowcast).astype(float)
    out['predicted_vote_gpt'] = out['정당'].map(gpt_out).astype(float)
    out['predicted_vote_ml'] = pd.Series(ml_pred, index=out.index) if ml_pred is not None else pd.NA

    out['ml_p50_lo'] = p50_lo if p50_lo is not None else pd.NA
    out['ml_p50_hi'] = p50_hi if p50_hi is not None else pd.NA
    out['ml_p80_lo'] = p80_lo if p80_lo is not None else pd.NA
    out['ml_p80_hi'] = p80_hi if p80_hi is not None else pd.NA

    out['mc_win_prob'] = out['정당'].map(mc_win_prob).astype(float)
    out['mc_p50'] = out['정당'].map(mc_p50).astype(float)
    out['mc_p50_lo'] = out['정당'].map(mc_p50_lo).astype(float)
    out['mc_p50_hi'] = out['정당'].map(mc_p50_hi).astype(float)
    out['mc_p80_lo'] = out['정당'].map(mc_p80_lo).astype(float)
    out['mc_p80_hi'] = out['정당'].map(mc_p80_hi).astype(float)

    cols = [
        '정당',
        'nowcast_pp',
        'predicted_vote_gpt', 'predicted_vote_ml', 'ml_p50_lo', 'ml_p50_hi', 'ml_p80_lo', 'ml_p80_hi',
        'mc_p50', 'mc_p50_lo', 'mc_p50_hi', 'mc_p80_lo', 'mc_p80_hi', 'mc_win_prob',
    ]
    return out[cols]

# ---------- 후보 예측(전이행렬 기반) ----------
def predict_candidates_via_transfer(nowcast_party: pd.Series,
                                    transfer: pd.DataFrame,
                                    sigma_pp: float = 2.5,
                                    n_sims: int = 5000,
                                    seed: int = 42) -> pd.DataFrame:
    """
    party nowcast(%) → 후보 득표율/승률
    transfer: index=후보, columns=정당, 각 '정당' 열 합이 1(>0일 때만)
    """
    parties = [p for p in transfer.columns if p in nowcast_party.index]
    transfer = transfer[parties]  # (C,P)
    mean_party = nowcast_party.loc[parties].astype(float).values  # (P,)
    cand_names = transfer.index.tolist()
    C, P = transfer.shape

    # 후보 평균 득표율(선형 변환) + 합 100 보정
    mean_cand = transfer.values @ mean_party  # (C,)
    s = mean_cand.sum()
    mean_cand = (mean_cand * (100.0 / s)) if s > 0 else np.full(C, 100.0 / max(C, 1))

    # 파티 분포 MC → 후보로 선형 변환
    rng = np.random.default_rng(seed)
    sigma_indiv = max(0.1, float(sigma_pp) / np.sqrt(2.0))
    sims_party = rng.normal(loc=mean_party, scale=sigma_indiv, size=(n_sims, P))
    sims_party = np.clip(sims_party, 0, None)
    sims_party = sims_party * (100.0 / np.maximum(1e-12, sims_party.sum(axis=1, keepdims=True)))
    sims_cand = sims_party @ transfer.T.values  # (n_sims, C)
    sims_cand = sims_cand * (100.0 / np.maximum(1e-12, sims_cand.sum(axis=1, keepdims=True)))

    winners = sims_cand.argmax(axis=1)
    win_prob = np.bincount(winners, minlength=C) / float(n_sims)

    q50 = np.quantile(sims_cand, 0.50, axis=0)
    q25 = np.quantile(sims_cand, 0.25, axis=0)
    q75 = np.quantile(sims_cand, 0.75, axis=0)
    q10 = np.quantile(sims_cand, 0.10, axis=0)
    q90 = np.quantile(sims_cand, 0.90, axis=0)

    out = pd.DataFrame({
        '후보': cand_names,
        'cand_p50': q50, 'cand_p50_lo': q25, 'cand_p50_hi': q75,
        'cand_p80_lo': q10, 'cand_p80_hi': q90,
        'cand_win_prob': win_prob,
    }).sort_values('cand_win_prob', ascending=False).reset_index(drop=True)
    return out
