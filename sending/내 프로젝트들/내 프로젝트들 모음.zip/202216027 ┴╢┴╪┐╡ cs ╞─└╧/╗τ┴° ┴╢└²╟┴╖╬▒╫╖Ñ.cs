﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class Form1 : Form
    {
        private Image originalImage;
        private float currentScale = 1f;

        public Form1()
        {
            InitializeComponent();
            this.Load += Form1_Load;  // 생성자 내부에서 이벤트 연결
        }  // ← 생성자 닫힘

        private void Form1_Load(object sender, EventArgs e)
        {
            btn.Click += btn_Click;
            trackBar1.Scroll += trackBar1_Scroll;
        }

        private void 열기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "이미지 파일|*.jpg;*.jpeg;*.png;*.bmp|모든 파일|*.*";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                originalImage = Image.FromFile(ofd.FileName);
                currentScale = 1f;
                trackBar1.Value = 10;

                pictureBox1.SizeMode = PictureBoxSizeMode.Normal; 
                pictureBox1.Image = new Bitmap(originalImage);
                pictureBox1.Size = originalImage.Size;  
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            if (originalImage == null) return;

            currentScale = trackBar1.Value / 10f;
            int newWidth = (int)(originalImage.Width * currentScale);
            int newHeight = (int)(originalImage.Height * currentScale);

            Bitmap resized = new Bitmap(originalImage, new Size(newWidth, newHeight));


            pictureBox1.Image = resized;
            pictureBox1.Size = resized.Size;
        }

        private void 닫기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 글꼴ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog();

            if (fontDialog.ShowDialog() == DialogResult.OK)
            {
                label1.Font = fontDialog.Font;
            }
        }

        private void btn_Click(object sender, EventArgs e)
        {
            if (originalImage == null) return;

            pictureBox1.Image = new Bitmap(originalImage);
            currentScale = 1f;
            trackBar1.Value = 10;
        }
    }
}

