﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class Form3: Form
    {
        private char currentPlayer = 'X';
        private char[] board = new char[9];
        public Form3()
        {

            InitializeComponent();
            ResetBoardState();
        }
        private void ResetBoardState()
        {
            for (int i = 0; i < 9; i++)
                board[i] = '\0';
        }

        private void CheckGameStatus()
        {
            if (CheckWin())
            {
                char winnerPlayer = (currentPlayer == 'X') ? 'O' : 'X';
                string winnerName = (winnerPlayer == 'X') ? "흑돌" : "백돌";
                labelResult.Text = $"{winnerName} 승리!";
                MessageBox.Show(winnerName + "승리 !", "승패확인 프로그램",MessageBoxButtons.OK,MessageBoxIcon.Information);
                DisableAllButtons();
            }
            else if (IsDraw())
            {
                labelResult.Text = "무승부입니다!";
                MessageBox.Show("무승부 입니다", "승패확인 프로그램", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DisableAllButtons();
            }
            else
            {
                labelResult.Text = "승패확인";
            }
        }

        private bool IsDraw()
        {
            foreach (char c in board)
            {
                if (c != 'X' && c != 'O')
                    return false;
            }
            return true;
        }
        private void DisableAllButtons()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
        }
        private bool CheckWin()
        {
            int[,] winPatterns = new int[,]
            {
                {0,1,2}, {3,4,5}, {6,7,8},
                {0,3,6}, {1,4,7}, {2,5,8},
                {0,4,8}, {2,4,6}
            };

            for (int i = 0; i < winPatterns.GetLength(0); i++)
            {
                int a = winPatterns[i, 0];
                int b = winPatterns[i, 1];
                int c = winPatterns[i, 2];

                if (board[a] != '\0' && board[a] == board[b] && board[b] == board[c])
                    return true;
            }
            return false;
        }


        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image == null)
            {
                if (currentPlayer == 'X')
                {
                    pictureBox1.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\2.png");
                    board[0] = 'X';
                    currentPlayer = 'O';
                }
                else
                {
                    pictureBox1.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\1.png");
                    board[0] = 'O';
                    currentPlayer = 'X';
                }
                button1.Enabled = false;
                CheckGameStatus();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (pictureBox2.Image == null)
            {
                if (currentPlayer == 'X')
                {
                    pictureBox2.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\2.png");
                    board[1] = 'X';
                    currentPlayer = 'O';
                }
                else
                {
                    pictureBox2.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\1.png");
                    board[1] = 'O';
                    currentPlayer = 'X';
                }
                button2.Enabled = false;
                CheckGameStatus();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (pictureBox3.Image == null)
            {
                if (currentPlayer == 'X')
                {
                    pictureBox3.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\2.png");
                    board[2] = 'X';
                    currentPlayer = 'O';
                }
                else
                {
                    pictureBox3.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\1.png");
                    board[2] = 'O';
                    currentPlayer = 'X';
                }
                button3.Enabled = false;
                CheckGameStatus();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (pictureBox4.Image == null)
            {
                if (currentPlayer == 'X')
                {
                    pictureBox4.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\2.png");
                    board[3] = 'X';
                    currentPlayer = 'O';
                }
                else
                {
                    pictureBox4.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\1.png");
                    board[3] = 'O';
                    currentPlayer = 'X';
                }
                button4.Enabled = false;
                CheckGameStatus();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (pictureBox5.Image == null)
            {
                if (currentPlayer == 'X')
                {
                    pictureBox5.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\2.png");
                    board[4] = 'X';
                    currentPlayer = 'O';
                }
                else
                {
                    pictureBox5.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\1.png");
                    board[4] = 'O';
                    currentPlayer = 'X';
                }
                button5.Enabled = false;
                CheckGameStatus();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (pictureBox6.Image == null)
            {
                if (currentPlayer == 'X')
                {
                    pictureBox6.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\2.png");
                    board[5] = 'X';
                    currentPlayer = 'O';
                }
                else
                {
                    pictureBox6.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\1.png");
                    board[5] = 'O';
                    currentPlayer = 'X';
                }
                button6.Enabled = false;
                CheckGameStatus();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (pictureBox7.Image == null)
            {
                if (currentPlayer == 'X')
                {
                    pictureBox7.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\2.png");
                    board[6] = 'X';
                    currentPlayer = 'O';
                }
                else
                {
                    pictureBox7.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\1.png");
                    board[6] = 'O';
                    currentPlayer = 'X';
                }
                button7.Enabled = false;
                CheckGameStatus();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (pictureBox8.Image == null)
            {
                if (currentPlayer == 'X')
                {
                    pictureBox8.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\2.png");
                    board[7] = 'X';
                    currentPlayer = 'O';
                }
                else
                {
                    pictureBox8.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\1.png");
                    board[7] = 'O';
                    currentPlayer = 'X';
                }
                button8.Enabled = false;
                CheckGameStatus();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (pictureBox9.Image == null)
            {
                if (currentPlayer == 'X')
                {
                    pictureBox9.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\2.png");
                    board[8] = 'X';
                    currentPlayer = 'O';
                }
                else
                {
                    pictureBox9.Image = Image.FromFile("C:\\Users\\cyci1234\\Desktop\\cpic\\1.png");
                    board[8] = 'O';
                    currentPlayer = 'X';
                }
                button9.Enabled = false;
                CheckGameStatus();
            }
        }

        private void resetbutton_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
            pictureBox2.Image = null;
            pictureBox3.Image = null;
            pictureBox4.Image = null;
            pictureBox5.Image = null;
            pictureBox6.Image = null;
            pictureBox7.Image = null;
            pictureBox8.Image = null;
            pictureBox9.Image = null;

            ResetBoardState();

            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = true;

            labelResult.Text = "승패확인";
        }
    }
}
