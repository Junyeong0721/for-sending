# 충청남도 지역 가이드 AI — 백엔드 (Python FastAPI)
실행: venv 생성 → `pip install -r requirements.txt` → `python app.py`
