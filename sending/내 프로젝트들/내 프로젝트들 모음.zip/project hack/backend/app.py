import os, json, math, time, re
from typing import List, Dict, Any, Optional
from pathlib import Path

import requests
from fastapi import FastAPI, UploadFile, File, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
PLACES_PATH = DATA_DIR / "initial_places.json"

app = FastAPI(title="충청남도 지역 가이드 AI", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# 정적/PWA 자산 서빙
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

@app.get("/", response_class=HTMLResponse)
def home():
    html = (BASE_DIR / "templates" / "index.html").read_text(encoding="utf-8")
    return HTMLResponse(content=html, status_code=200)

def load_local_places() -> List[Dict[str, Any]]:
    if PLACES_PATH.exists():
        try:
            return json.loads(PLACES_PATH.read_text(encoding="utf-8"))
        except Exception:
            return []
    return []

PLACES = load_local_places()

def regions() -> List[str]:
    return sorted(list({p["region"] for p in PLACES})) or ["충청남도"]

def haversine(lat1, lon1, lat2, lon2):
    R = 6371.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dlambda/2)**2
    return 2 * R * math.atan2(math.sqrt(a), math.sqrt(1-a))

def text_match(q: str, p: Dict[str, Any]) -> float:
    if not q: return 0.2
    t = (p.get("name","") + " " + " ".join(p.get("tags",[])) + " " + p.get("description","")).lower()
    q = q.lower()
    score = 0.0
    for token in re.split(r"\s+", q):
        if token and token in t:
            score += 1.0
    return score

KAKAO_KEY = os.getenv("KAKAO_REST_KEY", "")
TOUR_KEY = os.getenv("TOURAPI_KEY", "")
USE_EXTERNAL = os.getenv("USE_EXTERNAL_APIS", "0") == "1"

_cache: Dict[str, Dict[str, Any]] = {}
def cache_get(key: str):
    v = _cache.get(key)
    if v and time.time() - v["t"] < 60:
        return v["data"]
    return None
def cache_set(key: str, data: Any):
    _cache[key] = {"t": time.time(), "data": data}

def kakao_search(keyword: str, lat: Optional[float]=None, lng: Optional[float]=None, radius: int=5000, page: int=1) -> Dict[str, Any]:
    if not KAKAO_KEY: return {"documents": []}
    headers = {"Authorization": f"KakaoAK {KAKAO_KEY}"}
    url = "https://dapi.kakao.com/v2/local/search/keyword.json"
    params = {"query": keyword, "page": page, "size": 15}
    if lat is not None and lng is not None:
        params.update({"y": lat, "x": lng, "radius": radius})
    ck = f"kakao:{json.dumps(params, sort_keys=True)}"
    c = cache_get(ck)
    if c is not None: return c
    r = requests.get(url, headers=headers, params=params, timeout=8)
    r.raise_for_status()
    data = r.json()
    cache_set(ck, data)
    return data

def tourapi_festivals(area_code: Optional[str]=None, event_start: Optional[str]=None, event_end: Optional[str]=None, page: int=1) -> Dict[str, Any]:
    if not TOUR_KEY: return {"response": {"body": {"items": {"item": []}}}}
    base = "https://apis.data.go.kr/B551011/KorService1/searchFestival1"
    params = {
        "serviceKey": TOUR_KEY,
        "MobileOS": "ETC",
        "MobileApp": "cn-guide",
        "_type": "json",
        "numOfRows": 30,
        "pageNo": page
    }
    if area_code: params["areaCode"] = area_code
    if event_start: params["eventStartDate"] = event_start
    if event_end: params["eventEndDate"] = event_end
    ck = f"tour:{json.dumps(params, sort_keys=True)}"
    c = cache_get(ck)
    if c is not None: return c
    r = requests.get(base, params=params, timeout=10)
    r.raise_for_status()
    data = r.json()
    cache_set(ck, data)
    return data

class SearchReq(BaseModel):
    region: Optional[str] = None
    q: Optional[str] = ""
    categories: List[str] = Field(default_factory=list)
    center_lat: Optional[float] = None
    center_lng: Optional[float] = None
    sort: str = "best"
    use_external: bool = False

class ItineraryReq(BaseModel):
    region: str
    hours: int = 8
    categories: List[str] = Field(default_factory=lambda: ["eat","attraction","cafe","festival"])
    start_lat: Optional[float] = None
    start_lng: Optional[float] = None

class ChatReqBody(BaseModel):
    message: str
    region: Optional[str] = None
    model: str = "auto"

@app.post("/api/search")
def api_search(req: SearchReq):
    items = [p for p in PLACES if (not req.region or p["region"] == req.region)]
    if req.categories:
        items = [p for p in items if p["category"] in req.categories]

    ext_items = []
    if req.use_external and USE_EXTERNAL:
        if any(c in req.categories for c in ("eat","cafe")) or not req.categories:
            kw = req.q or "맛집"
            try:
                data = kakao_search(kw, req.center_lat, req.center_lng, radius=5000, page=1)
                for d in data.get("documents", []):
                    ext_items.append({
                        "id": f"kakao:{d.get('id')}",
                        "name": d.get("place_name"),
                        "category": "eat" if "카페" not in (d.get("category_name") or "") else "cafe",
                        "region": req.region or "충청남도",
                        "lat": float(d.get("y")) if d.get("y") else None,
                        "lng": float(d.get("x")) if d.get("x") else None,
                        "rating": 4.2,
                        "tags": ["kakao"],
                        "description": d.get("road_address_name") or d.get("address_name") or "",
                        "source": "kakao"
                    })
            except Exception:
                pass
        if ("festival" in req.categories) or (not req.categories):
            try:
                data = tourapi_festivals(area_code=os.getenv("TOUR_AREA_CODE"))
                items_raw = (((data or {}).get("response", {}) or {}).get("body", {}) or {}).get("items", {}) or {}
                for it in items_raw.get("item", []) or []:
                    ext_items.append({
                        "id": f"tour:{it.get('contentid')}",
                        "name": it.get("title"),
                        "category": "festival",
                        "region": req.region or "충청남도",
                        "lat": float(it.get("mapy")) if it.get("mapy") else None,
                        "lng": float(it.get("mapx")) if it.get("mapx") else None,
                        "rating": 4.0,
                        "tags": ["festival","tourapi"],
                        "description": (it.get("eventstartdate","") + " ~ " + it.get("eventenddate","")).strip(),
                        "source": "tourapi"
                    })
            except Exception:
                pass

    merged = items + [e for e in ext_items if e.get("lat") and e.get("lng")]

    scored = []
    for p in merged:
        s = text_match(req.q or "", p) + 0.25 * float(p.get("rating", 0))
        dist = None
        if req.center_lat is not None and req.center_lng is not None and p.get("lat") and p.get("lng"):
            dist = haversine(req.center_lat, req.center_lng, p["lat"], p["lng"])
            s += max(0.0, 1.0 - (dist / 10.0))
        scored.append({"place": p, "score": s, "dist": dist})

    if req.sort == "distance" and any(s["dist"] is not None for s in scored):
        scored.sort(key=lambda x: (x["dist"] if x["dist"] is not None else 1e9))
    elif req.sort == "rating":
        scored.sort(key=lambda x: (-x["place"].get("rating", 0), -x["score"]))
    else:
        scored.sort(key=lambda x: (-x["score"], -x["place"].get("rating",0)))
    return {"regions": regions(), "results": scored}

@app.post("/api/itinerary")
def api_itinerary(req: ItineraryReq):
    items = [p for p in PLACES if p["region"] == req.region and p["category"] in req.categories]
    if not items:
        return {"stops": []}
    center_lat = req.start_lat if req.start_lat is not None else sum(p["lat"] for p in items)/len(items)
    center_lng = req.start_lng if req.start_lng is not None else sum(p["lng"] for p in items)/len(items)
    items.sort(key=lambda p: p.get("rating",0), reverse=True)
    cand = items[:12]
    route = []
    cur_lat, cur_lng = center_lat, center_lng
    remaining = cand.copy()
    while remaining and len(route) < max(4, req.hours//2):
        nxt = min(remaining, key=lambda p: haversine(cur_lat, cur_lng, p["lat"], p["lng"]))
        route.append(nxt); cur_lat, cur_lng = nxt["lat"], nxt["lng"]; remaining.remove(nxt)
    total_min = sum(90 if p["category"] in ("attraction","festival") else 60 for p in route)
    return {"stops": route, "est_minutes": total_min, "center": {"lat": center_lat, "lng": center_lng}}

@app.get("/api/route_osrm")
def api_route_osrm(
    start_lat: float = Query(...), start_lng: float = Query(...),
    end_lat: float = Query(...), end_lng: float = Query(...)
):
    url = (
        "https://router.project-osrm.org/route/v1/driving/"
        f"{start_lng},{start_lat};{end_lng},{end_lat}"
        "?overview=full&geometries=geojson"
    )
    r = requests.get(url, timeout=10); r.raise_for_status()
    data = r.json(); route = data["routes"][0]
    coords_lonlat = route["geometry"]["coordinates"]
    coords_latlon = [[y, x] for x, y in coords_lonlat]
    return {"coords": coords_latlon, "distance_m": int(route["distance"]), "duration_s": int(route["duration"])}

USE_HF = os.getenv("MIDM_BACKEND", "mock") == "hf"
HF_MODELS = {"mini": "K-intelligence/Midm-2.0-Mini-Instruct","base": "K-intelligence/Midm-2.0-Base-Instruct"}
_tokenizer = None; _model = None; _loaded = None

def hf_generate(prompt: str, key: str = "mini") -> str:
    global _tokenizer, _model, _loaded
    repo = HF_MODELS.get(key, HF_MODELS["mini"])
    if _loaded != repo:
        from transformers import AutoTokenizer, AutoModelForCausalLM
        import torch
        _tokenizer = AutoTokenizer.from_pretrained(repo)
        _model = AutoModelForCausalLM.from_pretrained(repo, torch_dtype=(torch.float16 if torch.cuda.is_available() else None))
        if torch.cuda.is_available():
            _model = _model.to("cuda")
        _loaded = repo
    import torch
    x = _tokenizer(prompt, return_tensors="pt")
    if torch.cuda.is_available():
        x = {k:v.to("cuda") for k,v in x.items()}
    y = _model.generate(**x, max_new_tokens=380, temperature=0.5, top_p=0.9, do_sample=True, eos_token_id=_tokenizer.eos_token_id)
    out = _tokenizer.decode(y[0], skip_special_tokens=True)
    return out[len(prompt):].strip()

def mock_generate(context: str, user: str) -> str:
    return ("요약 코스(예시)\n"
            f"- 지역: {context}\n"
            "- 오전: 대표 카페 → 산책/뷰 포인트\n"
            "- 점심: 현지 맛집(대기 피하려면 오픈런 권장)\n"
            "- 오후: 박물관/시장 → 기념품\n"
            "- 저녁: 야경 명소 또는 해변 산책\n"
            "Tip) 우천 시 실내 코스, 주말은 예약 추천.\n")

SYSTEM = ("너는 한국 지역 여행/로컬 가이드 AI다. 제공된 후보 데이터를 바탕으로 시간대별 코스를 제안한다. "
          "항상 근거리 동선, 피크타임 회피 팁, 우천 대안을 포함한다. "
          "모르는 정보는 추측하지 말고 '정보 없음'으로 표기한다. 불릿 리스트로 간결히 작성한다.")

class ChatReqBody(BaseModel):
    message: str
    region: Optional[str] = None
    model: str = "auto"

@app.post("/api/chat")
def api_chat(req: ChatReqBody):
    reg = req.region or "충청남도"
    pool = [p for p in PLACES if p["region"] == reg]
    pool.sort(key=lambda p: p.get("rating",0), reverse=True)
    top = pool[:8]
    bullets = "\n".join([f"- {p['name']} ({p['category']}, ★{p.get('rating',0)}, {p['region']})" for p in top])
    prompt = f"""{SYSTEM}
[장소 후보]
{bullets}

[사용자 문의]
{req.message}

[응답]
"""
    route = "mini" if req.model != "base" else "base"
    if req.model == "auto":
        route = "base" if len(req.message) > 200 else "mini"
    ans = hf_generate(prompt, "base" if route=="base" else "mini") if USE_HF else mock_generate(reg, req.message)
    return {"route": route, "reply": ans, "used": top}

@app.post("/api/ingest")
def api_ingest(file: UploadFile = File(...)):
    content = file.file.read().decode("utf-8", errors="ignore")
    try:
        new_items = json.loads(content); assert isinstance(new_items, list)
    except Exception:
        return {"ok": False, "error": "JSON list expected"}
    data = load_local_places(); data.extend(new_items)
    PLACES_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    global PLACES; PLACES = load_local_places()
    return {"ok": True, "count": len(new_items), "total": len(PLACES)}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=False)
