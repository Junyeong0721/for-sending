# 충남도립대학교 · CNSU Lucky Spin

충남도립대학교 홍보 행사에서 사용할 수 있는 **오프라인 경품 돌림판**입니다.
로그인, 서버, 설치 과정 없이 실행합니다. 학교 로고와 학교 색상을 적용한 간결한 행사 화면입니다.

## 바로 사용하기

GitHub 저장소의 **Releases**에서 배포 파일을 받으세요.

| 파일                                    | 사용 방법                                                         |
| --------------------------------------- | ----------------------------------------------------------------- |
| `CNSU-Lucky-Spin-1.0.2-Windows-x64.exe` | Windows 10/11 64비트에서 더블클릭                                 |
| `CNSU-Lucky-Spin.html`                  | Windows·macOS·Linux의 최신 Chrome, Edge, Firefox, Safari에서 열기 |

Windows 프로그램에는 실행 환경이 포함되어 있어 Node.js, Python, WebView2를 별도로 설치하지 않아도 됩니다. HTML 파일도 코드·그림·스타일이 모두 들어 있어 파일 하나로 작동합니다. 상단 학교 로고를 눌러 학교 홈페이지를 열 때만 인터넷이 필요합니다.

### 행사 진행

1. 이벤트 이름과 경품 이름을 수정합니다. 경품은 2~12개입니다.
2. 당첨 확률을 **0~100 사이의 정수**로 입력합니다. 소수점은 입력되지 않습니다.
3. 합계가 **100%**인지 확인하고 **설정 적용**을 누릅니다.
4. **돌림판 돌리기** 또는 Space 키로 추첨합니다.
5. **행사 진행 모드**를 누르면 설정 화면을 숨겨 행사 화면을 크게 보여줍니다. Esc 또는 돌아가기 버튼으로 해제합니다. Windows 앱에서는 F11도 지원합니다.

처음 표시되는 경품은 예시입니다. 행사에서 실제로 제공할 경품으로 바꿔 사용하세요.

### 확률과 결과

- 각 칸은 가독성을 위해 같은 크기로 표시합니다. 당첨은 **설정한 확률**을 따릅니다.
- 0% 경품은 당첨되지 않습니다. 100% 경품은 매번 당첨됩니다.
- 매 회 독립 추첨이므로 설정한 비율만큼의 당첨 수량을 보장하지 않습니다. 경품 재고 차감 기능은 없습니다.
- Web Crypto 보안 난수로 0~99의 정수를 균일하게 뽑습니다. 범위 변환은 rejection sampling을 사용합니다.
- 당첨 결과를 먼저 선택하고 바늘이 해당 칸 안에서 멈추도록 애니메이션을 계산합니다.
- 추첨 중에는 재추첨 및 설정 변경을 막습니다.

### 저장·백업

- 설정과 최근 100회 추첨 기록은 현재 기기에 자동 저장됩니다. 서버로 보내지 않습니다.
- Windows 앱: 사용자 프로필의 Electron `userData` 폴더 아래에 저장합니다. 실행파일을 바꿔도 앱 이름을 유지하면 설정을 이어서 사용합니다.
- HTML 파일: 브라우저의 파일 저장 정책을 따릅니다. 파일 위치나 브라우저를 바꾸거나 브라우저 데이터를 삭제하면 설정이 유지되지 않을 수 있습니다.
- 기록 탭에서 CSV로 내보낼 수 있습니다.

### Windows 실행 안내

이 배포본은 코드 서명 인증서로 서명하지 않았습니다. Windows에서 게시자를 확인할 수 없다는 안내가 나타날 수 있습니다. 배포 저장소와 `SHA256SUMS.txt`의 해시를 확인하거나, HTML 버전을 사용하거나, 아래 방법으로 직접 빌드할 수 있습니다.

## 개발 및 빌드

Node.js 24 LTS와 npm을 권장합니다. 저장소를 받은 후 프로젝트 폴더에서 실행하세요.

```sh
npm ci
npm run build
npm run typecheck
npm test
```

`npm run build`는 독립 실행 HTML과 앱 아이콘을 만듭니다. 개발 시에도 먼저 실행하세요.

```sh
npm start         # Electron 개발 실행
npm run preview   # 브라우저 미리보기: http://127.0.0.1:5180/
npm run dist:win  # Windows x64 portable EXE 생성
node scripts/prepare-release.mjs
```

Windows 실행파일은 Windows에서 빌드하세요. 빌드에는 패키지와 Electron 다운로드를 위한 인터넷이 필요하지만, 완성된 앱 실행에는 필요하지 않습니다. `release/1.0.2/`에 EXE가, `dist/`에 HTML이, `release/1.0.2/distribution/`에 배포용 파일 모음과 체크섬이 만들어집니다.

## 코드 구조

```text
src/App.tsx              화면, 입력, 추첨 진행, 기록, 설정 가져오기/내보내기
src/wheel.ts             확률 검증, 난수, 당첨 계산, 저장 파일 검증
src/styles.css           반응형 학교 디자인
src/main.tsx             React 시작점
assets/cnsu-logo.png     제공받은 학교 로고 원본
scripts/build.mjs        네트워크 의존성이 없는 단일 HTML 빌드
electron/main.cjs        보안 설정이 적용된 데스크톱 앱
tests/wheel.test.mjs     확률/바늘 위치/저장 데이터 테스트
.github/workflows/      GitHub 자동 검사와 Windows 빌드
```

## GitHub에 공개하기

1. 이 소스 폴더의 파일을 새 GitHub 저장소에 올립니다. `.github`와 `.gitignore`도 포함하세요.
2. `node_modules/`, `release/`, 개인 설정 파일은 소스 저장소에 올리지 않습니다.
3. **Actions → Build Windows release → Run workflow**를 실행하면 Windows에서 자동 빌드한 배포 파일을 Artifacts에서 받을 수 있습니다.
4. **Releases → Draft a new release**에서 버전 태그(예: `v1.0.2`)와 설명을 입력합니다.
5. 준비된 EXE, HTML, 사용 안내, 라이선스 파일, `SHA256SUMS.txt`를 Release 첨부파일로 올리고 공개합니다. EXE는 소스 코드 업로드가 아닌 Release 첨부파일로 배포하세요.

워크플로는 빌드 아티팩트만 생성하며 자동으로 공개 릴리스를 게시하지 않습니다.

## 라이선스 및 브랜딩

앱의 원본 코드는 [MIT](LICENSE)로 공개합니다. 학교 이름·로고·상표와 외부 라이브러리는 MIT 적용 범위에서 제외됩니다. [BRANDING.md](BRANDING.md)와 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)를 함께 확인하세요.

공식 학교 안내: [충남도립대학교](https://www.cnsu.ac.kr/univ/main.do) · [입학 안내](https://www.cnsu.ac.kr/entra/main.do)
